import os
from copy import deepcopy
from enoppy.paper_based.pdo_2022 import *
from scipy.stats import cauchy
PopSize = 50
DimSize = 10
LB = [-100] * DimSize
UB = [100] * DimSize
TrialRuns =20
curFEs = 0
MaxFEs = DimSize * 1000

Pop = np.zeros((PopSize, DimSize))
FitPop = np.zeros(PopSize)

FuncNum = 0
H = 5
muF = [0.3] * H
muCr = [0.5] * H

Fail_F = []
Fail_Cr = []
Kf = 0.5       
Kr = 0.9       
K = 2          

def weighted_lehmer_mean(S_F, delta_f):
   
    weights = delta_f / np.sum(delta_f)
    numerator = np.sum(weights * (np.array(S_F) ** 2))
    denominator = np.sum(weights * np.array(S_F))
    return numerator / denominator


def weighted_geometric_mean(S_Cr, delta_f):
    
    weights = delta_f / np.sum(delta_f)
    product = np.prod(np.array(S_Cr) ** weights)
    return product
def meanL(arr):
    numer = 0
    denom = 0
    for var in arr:
        numer += var ** 2
        denom += var
    return numer / denom


def Initialization(func):
    global Pop, FitPop, curFEs, DimSize, muF, muCr, H, Fail_F, Fail_Cr
    for i in range(PopSize):
        for j in range(DimSize):
            Pop[i][j] = LB[j] + (UB[j] - LB[j]) * np.random.rand()
        FitPop[i] = func(Pop[i])
        curFEs += 1
    muF = [0.5] * H
    muCr = [0.5] * H
    Fail_F, Fail_Cr = [], []


def SHADEGSK( func):
    global Pop, FitPop, LB, UB, PopSize, DimSize, curFEs, Fail_F, Fail_Cr
    Off = np.zeros((PopSize, DimSize))
    FitOff = np.zeros(PopSize)
    F_idx, Cr_idx = np.random.randint(H), np.random.randint(H)


    Success_F, Success_Cr = [], []
    delta_f = []
    gamma = 2  
    P1 = int(PopSize * (1 - (curFEs / MaxFEs) ** gamma))
    for i in range(PopSize):
        F = cauchy.rvs(muF[F_idx], 0.1)
        F1 = cauchy.rvs(muF[F_idx], 0.1)
        Cr = np.clip(np.random.normal(muCr[Cr_idx], 0.1), 0, 1)

        candi = list(range(0, PopSize))
        candi.remove(i)
        r1, r2 = np.random.choice(candi, 2, replace=False)

        while True:  # F determination
            if F > 1:
                F = 1
                break
            elif F < 0:
                F = cauchy.rvs(muF[F_idx], 0.1)
            break

        Off[i] = Pop[i] + F * (Pop[np.argmin(FitPop)] - Pop[i]) + F1 * (Pop[r1] - Pop[r2])

        Junior = int(DimSize * (1 - curFEs / MaxFEs) ** K)
        Senior = DimSize - Junior
        p = (1 - curFEs / MaxFEs)
        random_dim_indices = np.random.permutation(DimSize)
        junior_dims = random_dim_indices[:Junior] 
        senior_dims = random_dim_indices[Junior:]  
        Off[i] = np.clip(Off[i], LB, UB)
        if i>P1:
        # Junior phase
            if Senior > 0:
                junior_mask = np.random.rand(Junior) < Kr
                idx_r = np.random.choice(PopSize)
                before_idx = i - 1 if i > 0 else 0
                next_idx = (i + 1) % PopSize

                if FitPop[i] > FitPop[idx_r]:
                    Off[i][junior_dims] += Kf * (
                                Pop[before_idx][junior_dims] - Pop[next_idx][junior_dims] + Pop[idx_r][junior_dims] -
                                Pop[i][junior_dims])
                else:
                    Off[i][junior_dims] += Kf * (
                                Pop[before_idx][junior_dims] - Pop[next_idx][junior_dims] + Pop[i][junior_dims] -
                                Pop[idx_r][junior_dims])

                Off[i][junior_dims] = np.where(junior_mask, Off[i][junior_dims], Pop[i][junior_dims])

            # Senior phase
            if Junior>0:
                senior_mask = np.random.rand(Senior) < Kr
                idx_m = np.random.choice(PopSize)
                best_idx = np.random.choice(np.argsort(FitPop)[:int(PopSize * 0.1)])
                worst_idx = np.random.choice(np.argsort(FitPop)[-int(PopSize * 0.1):])

                if FitPop[i] > FitPop[idx_m]:
                    Off[i][senior_dims] += Kf * (
                                Pop[best_idx][senior_dims] - Pop[worst_idx][senior_dims] + Pop[idx_m][senior_dims] - Pop[i][
                            senior_dims])
                else:
                    Off[i][senior_dims] += Kf * (
                                Pop[best_idx][senior_dims] - Pop[worst_idx][senior_dims] + Pop[i][senior_dims] - Pop[idx_m][
                            senior_dims])

                Off[i][senior_dims] = np.where(senior_mask, Off[i][senior_dims], Pop[i][senior_dims])


        Off[i] = np.clip(Off[i], LB, UB)
        jrand = np.random.randint(0, DimSize)  # bin crossover

        for j in range(DimSize):
            if np.random.rand() < Cr or j == jrand:
                pass
            else:
                if i > P1:
                    Off[i][j] = Pop[np.argmin(FitPop)][j]
                else:
                    Off[i][j] = Pop[i][j]

        for j in range(DimSize):
            if Off[i][j] < LB[j] or Off[i][j] > UB[j]:
                Off[i][j] = np.random.uniform(LB[j], UB[j])

        FitOff[i] = func(Off[i])
        curFEs += 1
        if FitOff[i] < FitPop[i]:
            Success_F.append(F)
            Success_Cr.append(Cr)
            delta_f.append(FitPop[i] - FitOff[i])

    for i in range(PopSize):
        if FitOff[i] < FitPop[i]:
            Pop[i] = deepcopy(Off[i])
            FitPop[i] = FitOff[i]

    if len(Success_F) > 0:
        muF[F_idx] = weighted_lehmer_mean(Success_F, delta_f)
        muCr[Cr_idx] = weighted_geometric_mean(Success_Cr, delta_f)
       

def RunKSHADE(func):
    global curFEs, MaxFEs, TrialRuns, Pop, FitPop, DimSize
    All_Trial_Best = []
    for i in range(TrialRuns):
        Best_list = []
        curFEs = 0
        Initialization(func)
        Best_list.append(min(FitPop))
        while curFEs < MaxFEs:
            SHADEGSK(func)
            Best_list.append(min(FitPop))
        All_Trial_Best.append(Best_list)
    np.savetxt("./KSHADE_Data/Engineer/" + str(FuncNum) + ".csv", All_Trial_Best, delimiter=",")


def main():
    global FuncNum, DimSize, MaxFEs, Pop, LB, UB

    MaxFEs = 10000

    Probs = [CBD(), CBHD(), CSP(), GTD(), IBD(), PLD(), PVP(), RCB(), SRD(), TBTD(), TCD(), WBP()]
    Names = ["CBDP", "CBHDP", "CSDP", "GTDP", "IBDP", "PLDP", "PVDP", "RCBDP", "SRDP", "TBTDP", "TCDP", "WBDP"]

    for i in range(len(Probs)):
        DimSize = Probs[i].n_dims
        LB = Probs[i].lb
        UB = Probs[i].ub
        Pop = np.zeros((PopSize, DimSize))
        FuncNum = Names[i]
        RunKSHADE(Probs[i].evaluate)


if __name__ == "__main__":
    if os.path.exists('./KSHADE_Data/Engineer') == False:
        os.makedirs('./KSHADE_Data/Engineer')
    main()
