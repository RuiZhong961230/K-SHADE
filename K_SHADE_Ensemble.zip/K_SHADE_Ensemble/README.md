

## Files

- `main_improved.py`: trains and evaluates eight base-model architectures over repeated runs.
- `model_factory.py`: creates the eight supported model architectures.
- `pokemon_coffee_final.py`: reads the CSV manifest, creates the fixed stratified split, and preprocesses the images.
- `final_ensemble_optimizer.py`: performs ensemble selection and weight optimization with K-SHADE.
- `K_SHADE.py`: implements the K-SHADE optimization algorithm.

## Data and Dependencies

The required Python packages are `torch`, `torchvision`, `numpy`, `pandas`, `scikit-learn`, `scipy`, and `Pillow`. The models use pretrained torchvision weights, which may be downloaded during the first run.

### Exact Package Versions

The principal package versions used by the experiments were:

```text
numpy==2.0.1
pandas==2.3.3
pillow==12.2.0
scikit-learn==1.7.1
scipy==1.15.3
torch==2.11.0+cu128
torchvision==0.26.0+cu128
```

Place `images.csv` and the `data/` directory beside the scripts. Alternatively, set `PUERTEA_DATA_DIR` to a directory containing both items. Each line of `images.csv` must have the following format:

```text
relative/image/path,integer_label
```

The task uses seven class labels. data sourse: https://www.kaggle.com/datasets/bmshahriaalam/tealeafbd-tea-leaf-disease-detection.

## Base-Model Outputs

Base-model results are written to the local `result/` directory.

- `<model_name>_run_<three-digit_run_id>_best_model.pth`: the checkpoint from the epoch with the highest validation accuracy for one model and one run. For example, `resnet18_run_000_best_model.pth` stores the best ResNet-18 checkpoint from run 0. Other epochs are not saved.
- `all_experiments_summary.csv`: one row per model and run, including the model name, run identifier, seed, best epoch, validation accuracy, test accuracy, elapsed time, and checkpoint filename.

To load a checkpoint, create the corresponding seven-class architecture with `ModelFactory`, read the checkpoint named in the `checkpoint` column, and load its state dictionary with `load_state_dict`.

##  Settings

### 1. Deep-Learning Training Parameters

- Base models: ResNet-18, Swin-T, ConvNeXt-Base, VGG-16, DenseNet-169, EfficientNet-B0, Inception-v3, and MobileNet-v3-Small.
- Maximum number of epochs: 20.
- Batch size: 256.
- Optimizer: Adam.
- Learning rate: `1e-3`.
- The learning rate remains constant; no learning-rate scheduler is used.
- Loss function: cross-entropy loss.
- An explicit L2 penalty of `0.01 × Σ||parameter||²` is added to the training loss.
- No early stopping is used; each successful run normally completes all 20 epochs.
- The checkpoint with the highest validation accuracy is selected.
- The selected checkpoint is restored before test-set evaluation.
- Training duration is not used as a stopping condition; wall-clock time is recorded separately for each run.

### 2. Dataset Split

- The dataset is divided into 60% training, 20% validation, and 20% testing subsets.
- Both split stages use label-stratified sampling.
- All architectures and repeated runs use the same fixed training, validation, and test split.

### 3. Deep-Learning Repetition and Seed Protocol

- `42` is the master seed.
- For repetition `r`, where `r` starts from zero, the run-specific seed is:

```text
run_seed = 42 + 100 × r
```

