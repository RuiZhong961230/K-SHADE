import torch
import os
import numpy as np
from sklearn.model_selection import train_test_split
from torch.utils.data import Dataset
from torchvision import transforms
from PIL import Image


class CoffeeDataset(Dataset):
    """咖啡叶病害数据集 - 使用分层抽样"""
    
    def __init__(self, root, csv_file, resize, mode):
        super().__init__()
        self.root = root
        self.resize = resize
        self.csv_file = csv_file
        self.mode = mode
        
        # 加载数据
        self.images, self.labels = self.load_csv()
        
        # 分层抽样分割
        self.images, self.labels = self.stratified_split()
        # D:\apl\puertea\images.csv
    def load_csv(self):
        """从CSV加载数据"""
        images, labels = [], []
        with open(self.csv_file, 'r', encoding='utf-8') as f:
            for line in f:
                if line.strip():
                    img, label = line.strip().split(',')
                    images.append(img)
                    labels.append(int(label))
        return images, labels
    
    def stratified_split(self):
        """分层抽样分割 (60% train, 20% val, 20% test)"""
        seed = 42
        images_np = np.array(self.images)
        labels_np = np.array(self.labels)
        
        if self.mode == 'train':
            # 60% 训练集
            train_img, _, train_lbl, _ = train_test_split(
                images_np, labels_np, train_size=0.6, 
                stratify=labels_np, random_state=seed
            )
            return list(train_img), list(train_lbl)
            
        elif self.mode == 'val':
            # 先分割出训练集
            _, temp_img, _, temp_lbl = train_test_split(
                images_np, labels_np, train_size=0.6,
                stratify=labels_np, random_state=seed
            )
            # 从剩余40%中取一半作为验证集 (20%)
            val_img, _, val_lbl, _ = train_test_split(
                temp_img, temp_lbl, train_size=0.5,
                stratify=temp_lbl, random_state=seed
            )
            return list(val_img), list(val_lbl)
            
        else:  # test
            _, temp_img, _, temp_lbl = train_test_split(
                images_np, labels_np, train_size=0.6,
                stratify=labels_np, random_state=seed
            )
            _, test_img, _, test_lbl = train_test_split(
                temp_img, temp_lbl, train_size=0.5,
                stratify=temp_lbl, random_state=seed
            )
            return list(test_img), list(test_lbl)
    
    def __len__(self):
        return len(self.images)
    
    def __getitem__(self, idx):
        img_path = os.path.join(self.root, self.images[idx])
        img_path = img_path.replace("\\", "/")
        label = self.labels[idx]
        
        tf = transforms.Compose([
            lambda x: Image.open(x).convert('RGB'),
            transforms.Resize((self.resize, self.resize)),
            transforms.ToTensor(),
            transforms.Normalize([0.485, 0.456, 0.406], 
                               [0.229, 0.224, 0.225])
        ])
        
        return tf(img_path), torch.tensor(label, dtype=torch.long)
