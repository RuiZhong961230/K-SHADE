"""
模型工厂：动态创建和管理模型
"""

import torch.nn as nn
import torchvision.models as models
from torchvision.models import (
    ResNet18_Weights, VGG16_Weights, DenseNet169_Weights,
    EfficientNet_B0_Weights, ConvNeXt_Base_Weights, Swin_T_Weights,
)

class Inception_v3(nn.Module):
    def __init__(self):
        super().__init__()
        self.base = models.inception_v3(pretrained=True)                           
        
        self.base.fc = nn.Sequential(
        nn.Flatten(), 
        nn.Linear(2048, 128),  
        nn.ReLU(),
        nn.Dropout(0.2),
        nn.Linear(128, 7)
    )
              
        
    def forward(self, x):
        x = self.base(x)
        return x

class ModelFactory:
    """模型工厂类，用于动态创建各种预训练模型"""
    
    @staticmethod
    def create_model(model_name, num_classes, pretrained=True):
        """
        根据模型名称创建模型
        
        Args:
            model_name: 模型名称
            num_classes: 输出类别数
            pretrained: 是否使用预训练权重
            
        Returns:
            PyTorch模型
        """
        model = None
        
        if model_name == "resnet18":
            weights = ResNet18_Weights.DEFAULT if pretrained else None
            model = models.resnet18(weights=weights)
            model.fc = nn.Linear(model.fc.in_features, num_classes)
            
        elif model_name == "vgg16":
            weights = VGG16_Weights.DEFAULT if pretrained else None
            model = models.vgg16(weights=weights)
            model.classifier[6] = nn.Linear(model.classifier[6].in_features, num_classes)
            
        elif model_name == "densenet169":
            weights = DenseNet169_Weights.DEFAULT if pretrained else None
            model = models.densenet169(weights=weights)
            model.classifier = nn.Linear(model.classifier.in_features, num_classes)
            
        # EfficientNet系列
        elif model_name == "efficientnet_b0":
            weights = EfficientNet_B0_Weights.DEFAULT if pretrained else None
            model = models.efficientnet_b0(weights=weights)
            model.classifier[1] = nn.Linear(model.classifier[1].in_features, num_classes)
            
        elif model_name == "inception_v3":
            model = Inception_v3()
            
        # MobileNet系列
        elif model_name == "mobilenet_v3_small":
            weights = models.MobileNet_V3_Small_Weights.DEFAULT if pretrained else None
            model = models.mobilenet_v3_small(weights=weights)
            model.classifier[3] = nn.Linear(model.classifier[3].in_features, num_classes)
            
        elif model_name == "convnext_base":
            weights = ConvNeXt_Base_Weights.DEFAULT if pretrained else None
            model = models.convnext_base(weights=weights)
            model.classifier[2] = nn.Linear(model.classifier[2].in_features, num_classes)
            
        elif model_name == "swin_t":
            weights = Swin_T_Weights.DEFAULT if pretrained else None
            model = models.swin_t(weights=weights)
            model.head = nn.Linear(model.head.in_features, num_classes)
            
        else:
            raise ValueError(f"未知模型名称: {model_name}")

        # 冻结部分参数（保留最后15层可训练）
        for param in list(model.parameters())[:-15]:
            param.requires_grad = False
        
        return model
    
    @staticmethod
    def get_model_input_size(model_name):
        """获取模型的推荐输入尺寸"""
        size_map = {
            "resnet18": 224, "swin_t": 224, "convnext_base": 224,
            "vgg16": 224, "densenet169": 224, "efficientnet_b0": 224,
            "inception_v3": 299, "mobilenet_v3_small": 224,
        }
        return size_map.get(model_name, 224)
    
