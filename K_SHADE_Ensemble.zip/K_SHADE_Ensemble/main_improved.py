import os
import time
import numpy as np
import torch
import pandas as pd
from pathlib import Path
import random
import copy

from pokemon_coffee_final import CoffeeDataset as Pokemon
from torch import optim, nn
from torch.utils.data import DataLoader
from model_factory import ModelFactory

global_path = Path(__file__).resolve().parent

def set_seed(seed=42):
    """设置所有随机种子以确保可重复性"""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)  # 如果使用多GPU
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    print(f"设置随机种子: {seed}")

def set_full_deterministic(seed=42):
    """设置完全确定性环境"""
    # 设置Python随机种子
    random.seed(seed)
    np.random.seed(seed)
    
    # 设置PyTorch随机种子
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    
    # 设置CUDA确定性
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    
    # 设置CUDA卷积算法确定性
    torch.backends.cudnn.enabled = True
    
    # 设置numpy的随机种子
    np.random.seed(seed)
    
    # 设置环境变量
    os.environ['PYTHONHASHSEED'] = str(seed)
    os.environ['CUBLAS_WORKSPACE_CONFIG'] = ':4096:8'
    
    print(f"已设置完全确定性环境，种子: {seed}")

class ExperimentLogger:
    """Keep timing and epoch metrics in memory only."""
    def __init__(self, model_name, trial_run):
        self.start_time = time.time()

    def log_epoch(self, *args):
        pass

    def get_total_time(self):
        return time.time() - self.start_time


def train_model(model, train_loader, val_loader, device, criterion, optimizer, 
                model_name, epochs, logger):
    """
    训练模型
    
    Returns:
        best_model: 最佳模型
        best_epoch: 最佳epoch
        best_val_acc: 最佳验证准确率
        train_preds: 训练集预测结果
        train_labels: 训练集真实标签
        val_preds: 验证集预测结果
        val_labels: 验证集真实标签
    """
    best_val_acc = -1
    best_epoch = 0
    best_model_state = None
    best_model = None
    # 收集所有预测结果
    all_train_preds = []
    all_train_labels = []
    all_val_preds = []
    all_val_labels = []
    
    for epoch in range(epochs):
        epoch_start_time = time.time()
        
        # 训练阶段
        model.train()
        train_loss = 0
        correct_train = 0
        total_train = 0
        epoch_train_preds = []
        epoch_train_labels = []
        
        for step, (x, y) in enumerate(train_loader):
            x, y = x.to(device), y.to(device)
            
            optimizer.zero_grad()
            logits = model(x)
            
            # 处理Inception模型
            if model_name == 'inception_v3':
                loss = criterion(logits.logits, y) if hasattr(logits, 'logits') else criterion(logits, y)
            else:
                loss = criterion(logits, y)
            
            # L2正则化
            l2_reg = torch.tensor(0.).to(device)
            for param in model.parameters():
                l2_reg += torch.norm(param).pow(2)
            loss = loss + 0.01 * l2_reg
            
            loss.backward()
            optimizer.step()
            
            train_loss += loss.item()
            
            # 获取预测结果
            if model_name == 'inception_v3' and hasattr(logits, 'logits'):
                _, preds = torch.max(logits.logits, 1)
            else:
                _, preds = torch.max(logits, 1)
            
            correct_train += (preds == y).sum().item()
            total_train += y.size(0)
            
            # 收集预测结果
            epoch_train_preds.extend(preds.cpu().numpy())
            epoch_train_labels.extend(y.cpu().numpy())
        
        train_acc = correct_train / total_train
        avg_train_loss = train_loss / len(train_loader)
        
        # 验证阶段
        model.eval()
        val_loss = 0
        correct_val = 0
        total_val = 0
        epoch_val_preds = []
        epoch_val_labels = []
        
        with torch.no_grad():
            for val_x, val_y in val_loader:
                val_x, val_y = val_x.to(device), val_y.to(device)
                
                logits = model(val_x)
                loss = criterion(logits, val_y)
                
                val_loss += loss.item()
                
                if model_name == 'inception_v3' and hasattr(logits, 'logits'):
                    _, val_preds = torch.max(logits.logits, 1)
                else:
                    _, val_preds = torch.max(logits, 1)
                
                correct_val += (val_preds == val_y).sum().item()
                total_val += val_y.size(0)
                
                # 收集预测结果
                epoch_val_preds.extend(val_preds.cpu().numpy())
                epoch_val_labels.extend(val_y.cpu().numpy())
        
        val_acc = correct_val / total_val
        avg_val_loss = val_loss / len(val_loader)
        
        # 更新最佳模型
        if val_acc > best_val_acc:
            best_val_acc = val_acc
            best_epoch = epoch
            # 保存当时的权重快照，防止后续训练覆盖
            best_model_state = copy.deepcopy(model.state_dict())
            best_model = model
            
        
        # 记录epoch结果
        epoch_time = time.time() - epoch_start_time
        current_lr = optimizer.param_groups[0]['lr']
        logger.log_epoch(epoch + 1, avg_train_loss, train_acc, 
                        avg_val_loss, val_acc, current_lr, epoch_time)
        
        
        # 收集所有预测结果
        all_train_preds.extend(epoch_train_preds)
        all_train_labels.extend(epoch_train_labels)
        all_val_preds.extend(epoch_val_preds)
        all_val_labels.extend(epoch_val_labels)
        
        print(f"Epoch {epoch}/{epochs}: "
              f"Train Loss: {avg_train_loss:.4f}, Train Acc: {train_acc:.4f}, "
              f"Val Loss: {avg_val_loss:.4f}, Val Acc: {val_acc:.4f}, "
              f"Time: {epoch_time:.2f}s")
    
    # 如果记录了最佳权重快照，则将其加载到模型中，返回为最佳模型
    if best_model_state is not None:
        model.load_state_dict(best_model_state)
        best_model = model

    return best_model, best_epoch, best_val_acc, all_train_preds, all_train_labels, all_val_preds, all_val_labels


def test_model(model, test_loader, device, model_name):
    """测试模型"""
    model.eval()
    all_preds = []
    all_labels = []
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    with torch.no_grad():
        for test_x, test_y in test_loader:
            test_x, test_y = test_x.to(device), test_y.to(device)
            
            logits = model(test_x)
            
            if model_name == 'inception_v3' and hasattr(logits, 'logits'):
                _, preds = torch.max(logits.logits, 1)
            else:
                _, preds = torch.max(logits, 1)
            
            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(test_y.cpu().numpy())
    
    # 计算准确率
    correct = sum(p == t for p, t in zip(all_preds, all_labels))
    test_acc = correct / len(all_labels)
    
    return test_acc, all_preds, all_labels


def generativeModel():
    """主训练函数"""
    # 设置全局随机种子
    set_seed(42)
    set_full_deterministic(42)
    # 配置参数
    data_root = Path(os.environ.get("PUERTEA_DATA_DIR", global_path))
    root = str(data_root / "data")
    csv_file = str(data_root / "images.csv")
    if not Path(csv_file).is_file() or not Path(root).is_dir():
        raise FileNotFoundError(f"请在 {data_root} 放置 images.csv 和 data/，或设置 PUERTEA_DATA_DIR")
    batchsz = 256
    lr = 1e-3
    epochs = 20
    TrialRuns = 1
    
    model_names = [
        "resnet18", "swin_t", "convnext_base", "vgg16",
        "densenet169", "efficientnet_b0", "inception_v3",
        "mobilenet_v3_small",
    ]
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"使用设备: {device}")
    
    factory = ModelFactory()
    
    # 训练全部八种模型
    test_models = model_names
    
    all_results = []
    output_dir = global_path / "result"
    output_dir.mkdir(exist_ok=True)
    
    for model_idx, model_name in enumerate(test_models):
        print(f"\n{'='*60}")
        print(f"开始训练模型: {model_name} ({model_idx+1}/{len(test_models)})")
        print(f"{'='*60}")
        
        # 获取模型输入尺寸
        input_size = factory.get_model_input_size(model_name)
        
        # 创建数据集 - 使用相同的随机种子确保数据划分一致
        # 注意：数据集划分已经在pokemon_coffee_final.py中使用固定种子42
        db_train = Pokemon(root, csv_file, input_size, 'train')
        db_val = Pokemon(root, csv_file, input_size, 'val')
        db_test = Pokemon(root, csv_file, input_size, 'test')
        
        print(f"数据集大小: 训练集={len(db_train)}, 验证集={len(db_val)}, 测试集={len(db_test)}")
        
        for trial_run in range(TrialRuns):
            print(f"\n试验运行 {trial_run+1}/{TrialRuns}")
            print(f"{'-'*40}")
            
            # 为每次试验运行设置特定的种子
            run_seed = 42 + trial_run * 100  # 每个运行使用不同的种子
            set_seed(run_seed)
            set_full_deterministic(run_seed)
            
            # 创建实验日志器
            logger = ExperimentLogger(model_name, trial_run)
            
            # 创建数据加载器 - 使用固定的shuffle顺序
            # 使用固定的随机种子来确保shuffle顺序一致
            g = torch.Generator()
            g.manual_seed(run_seed)
            
            train_loader = DataLoader(
                db_train, 
                batch_size=batchsz, 
                shuffle=True,
                generator=g  # 使用固定的生成器
            )

            val_loader = DataLoader(db_val, batch_size=batchsz, shuffle=False)
            test_loader = DataLoader(db_test, batch_size=batchsz, shuffle=False)
            
            # 创建模型
            model = factory.create_model(model_name, num_classes=7).to(device)
            
            # 创建优化器和损失函数
            optimizer = optim.Adam(model.parameters(), lr=lr)
            criterion = nn.CrossEntropyLoss()
            
            # 训练模型
            trained_model, best_epoch, best_val_acc, train_preds, train_labels, val_preds, val_labels = train_model(
                model, train_loader, val_loader, device, criterion, optimizer,
                model_name, epochs, logger
            )
           
            # 测试模型
            test_acc, test_preds, test_labels = test_model(
                trained_model, test_loader, device, model_name
            )
            
            # 每次试验只保存该次运行中验证准确率最高的 epoch。
            total_time = logger.get_total_time()
            checkpoint = f"{model_name}_run_{trial_run:03d}_best_model.pth"
            torch.save(trained_model.state_dict(), output_dir / checkpoint)
            print(f"最佳模型已保存: {output_dir / checkpoint}")

            # 记录结果
            result = {
                'model_name': model_name,
                'trial_run': trial_run,
                'seed': run_seed,
                'best_epoch': best_epoch,
                'best_val_acc': best_val_acc,
                'test_acc': test_acc,
                'total_time': total_time,
                'checkpoint': checkpoint,
            }
            all_results.append(result)
            
            print(f"试验 {trial_run+1} 完成: 验证准确率={best_val_acc:.4f}, "
                  f"测试准确率={test_acc:.4f}, 耗时={total_time:.2f}s")

    # 保存所有结果汇总
    if all_results:
        df_results = pd.DataFrame(all_results)
        summary_file = output_dir / "all_experiments_summary.csv"
        df_results.to_csv(summary_file, index=False)
        print(f"\n所有实验汇总已保存: {summary_file}")
        
        # 打印统计信息
        print(f"\n{'='*60}")
        print("实验统计信息")
        print(f"{'='*60}")
        
        for model_name in test_models:
            model_results = [r for r in all_results if r['model_name'] == model_name]
            if model_results:
                avg_val_acc = np.mean([r['best_val_acc'] for r in model_results])
                avg_test_acc = np.mean([r['test_acc'] for r in model_results])
                avg_time = np.mean([r['total_time'] for r in model_results])
                
                print(f"{model_name}:")
                print(f"  平均验证准确率: {avg_val_acc:.4f}")
                print(f"  平均测试准确率: {avg_test_acc:.4f}")
                print(f"  平均运行时间: {avg_time:.2f}s")
                print()


if __name__ == '__main__':
    
    # 运行训练
    generativeModel()
