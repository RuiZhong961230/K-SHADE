import numpy as np
from copy import deepcopy
from scipy.stats import cauchy

def K_SHADE(n, N_iter, Lb, Ub, dim, fobj):
    """
    K-SHADE算法实现
    
    参数:
    n: 种群大小
    N_iter: 迭代次数
    Lb: 下界列表或值
    Ub: 上界列表或值
    dim: 维度
    fobj: 目标函数
    
    返回:
    fmin: 最小适应度值
    best_pos: 最佳位置
    Convergence_curve: 收敛曲线
    """
    
    # 参数设置
    PopSize = n
    DimSize = dim
    MaxFEs = N_iter * PopSize  # 最大函数评估次数
    curFEs = 0
    
    # 边界处理
    if isinstance(Lb, (int, float)):
        LB = [Lb] * dim
    else:
        LB = Lb
        
    if isinstance(Ub, (int, float)):
        UB = [Ub] * dim
    else:
        UB = Ub
    
    # 初始化种群
    Pop = np.zeros((PopSize, DimSize))
    FitPop = np.zeros(PopSize)
    
    for i in range(PopSize):
        for j in range(DimSize):
            Pop[i][j] = LB[j] + (UB[j] - LB[j]) * np.random.rand()
        FitPop[i] = fobj(Pop[i])
        curFEs += 1
    
    # 记忆库参数
    H = 5
    memory_size = H
    muF = [0.5] * H
    muCr = [0.5] * H
    memory_index = 0
    
    # GSK参数
    Kf = 0.5       # GSK 缩放因子
    Kr = 0.9       # GSK 随机概率
    K = 2          # GSK 阶段划分指数
    
    # 辅助函数
    def weighted_lehmer_mean(S_F, delta_f):
        """计算加权Lehmer均值"""
        weights = delta_f / np.sum(delta_f)
        numerator = np.sum(weights * (np.array(S_F) ** 2))
        denominator = np.sum(weights * np.array(S_F))
        return numerator / denominator
    
    def weighted_geometric_mean(S_Cr, delta_f):
        """计算加权几何均值"""
        weights = delta_f / np.sum(delta_f)
        product = np.prod(np.array(S_Cr) ** weights)
        return product
    
    # 收敛曲线
    Convergence_curve = []
    Convergence_curve.append(np.min(FitPop))
    
    # 主循环
    while curFEs < MaxFEs:
        Off = np.zeros((PopSize, DimSize))
        FitOff = np.zeros(PopSize)
        F_idx, Cr_idx = np.random.randint(H), np.random.randint(H)
        
        Success_F, Success_Cr = [], []
        delta_f = []
        gamma = 2  # 调节参数
        P1 = int(PopSize * (1 - (curFEs / MaxFEs) ** gamma))
        
        for i in range(PopSize):
            # 生成F和Cr
            F = cauchy.rvs(muF[F_idx], 0.1)
            Cr = np.clip(np.random.normal(muCr[Cr_idx], 0.1), 0, 1)
            
            # 选择父代
            candi = list(range(0, PopSize))
            candi.remove(i)
            r1, r2 = np.random.choice(candi, 2, replace=False)
            
            # F边界处理
            while True:
                if F > 1:
                    F = 1
                    break
                elif F < 0:
                    F = cauchy.rvs(muF[F_idx], 0.1)
                break
            
            # DE变异
            best_idx = np.argmin(FitPop)
            Off[i] = Pop[i] + F * (Pop[best_idx] - Pop[i]) + F * (Pop[r1] - Pop[r2])
            
            # GSK阶段
            Junior = int(DimSize * (1 - curFEs / MaxFEs) ** K)
            Senior = DimSize - Junior
            
            # 随机打乱维度索引
            random_dim_indices = np.random.permutation(DimSize)
            junior_dims = random_dim_indices[:Junior]
            senior_dims = random_dim_indices[Junior:]
            
            Off[i] = np.clip(Off[i], LB, UB)
            
            if i > P1:
                # Junior phase
                if Junior > 0:
                    junior_mask = np.random.rand(Junior) < Kr
                    idx_r = np.random.choice(PopSize)
                    before_idx = i - 1 if i > 0 else 0
                    next_idx = (i + 1) % PopSize
                    
                    if FitPop[i] > FitPop[idx_r]:
                        Off[i][junior_dims] += Kf * (
                            Pop[before_idx][junior_dims] - Pop[next_idx][junior_dims] + 
                            Pop[idx_r][junior_dims] - Pop[i][junior_dims])
                    else:
                        Off[i][junior_dims] += Kf * (
                            Pop[before_idx][junior_dims] - Pop[next_idx][junior_dims] + 
                            Pop[i][junior_dims] - Pop[idx_r][junior_dims])
                    
                    Off[i][junior_dims] = np.where(junior_mask, Off[i][junior_dims], Pop[i][junior_dims])
                
                # Senior phase
                if Senior > 0:
                    senior_mask = np.random.rand(Senior) < Kr
                    idx_m = np.random.choice(PopSize)
                    best_idx = np.random.choice(np.argsort(FitPop)[:int(PopSize * 0.1)])
                    worst_idx = np.random.choice(np.argsort(FitPop)[-int(PopSize * 0.1):])
                    
                    if FitPop[i] > FitPop[idx_m]:
                        Off[i][senior_dims] += Kf * (
                            Pop[best_idx][senior_dims] - Pop[worst_idx][senior_dims] + 
                            Pop[idx_m][senior_dims] - Pop[i][senior_dims])
                    else:
                        Off[i][senior_dims] += Kf * (
                            Pop[best_idx][senior_dims] - Pop[worst_idx][senior_dims] + 
                            Pop[i][senior_dims] - Pop[idx_m][senior_dims])
                    
                    Off[i][senior_dims] = np.where(senior_mask, Off[i][senior_dims], Pop[i][senior_dims])
            
            # 边界处理
            Off[i] = np.clip(Off[i], LB, UB)
            
            # 交叉操作
            jrand = np.random.randint(0, DimSize)
            for j in range(DimSize):
                if np.random.rand() < Cr or j == jrand:
                    pass
                else:
                    if i > P1:
                        Off[i][j] = Pop[np.argmin(FitPop)][j]
                    else:
                        Off[i][j] = Pop[i][j]
            
            # 边界修复
            for j in range(DimSize):
                if Off[i][j] < LB[j] or Off[i][j] > UB[j]:
                    Off[i][j] = np.random.uniform(LB[j], UB[j])
            
            # 评估子代
            FitOff[i] = fobj(Off[i])
            curFEs += 1
            
            # 记录成功参数
            if FitOff[i] < FitPop[i]:
                Success_F.append(F)
                Success_Cr.append(Cr)
                delta_f.append(FitPop[i] - FitOff[i])
        
        # 选择操作
        for i in range(PopSize):
            if FitOff[i] < FitPop[i]:
                Pop[i] = deepcopy(Off[i])
                FitPop[i] = FitOff[i]
        
        # 更新记忆库
        if len(Success_F) > 0:
            muF[F_idx] = weighted_lehmer_mean(Success_F, delta_f)
            muCr[Cr_idx] = weighted_geometric_mean(Success_Cr, delta_f)
            memory_index = (memory_index + 1) % memory_size
        
        # 记录收敛曲线
        Convergence_curve.append(np.min(FitPop))
    
    # 获取最佳结果
    best_idx = np.argmin(FitPop)
    fmin = FitPop[best_idx]
    best_pos = Pop[best_idx]
    
    return fmin, best_pos, Convergence_curve


# 测试函数示例
def test_function():
    """测试函数：Sphere函数"""
    def sphere(x):
        return np.sum((x-2)**2)
    
    # 参数设置
    n = 50  # 种群大小
    N_iter = 1000  # 迭代次数
    dim = 10  # 维度
    Lb = -100  # 下界
    Ub = 100   # 上界
    
    # 运行算法
    fmin, best_pos, convergence_curve = K_SHADE(n, N_iter, Lb, Ub, dim, sphere)
    
    print(f"最小适应度值: {fmin}")
    print(f"最佳位置: {best_pos}")
    print(f"收敛曲线长度: {len(convergence_curve)}")
    
    return fmin, best_pos, convergence_curve


if __name__ == "__main__":
    # 运行测试
    fmin, best_pos, convergence_curve = test_function()