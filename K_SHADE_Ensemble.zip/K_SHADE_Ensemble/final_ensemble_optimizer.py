
import numpy as np
import torch
import json
import pandas as pd
from pathlib import Path
import os
import time
from datetime import datetime

BASE_DIR = Path(__file__).resolve().parent

from model_factory import ModelFactory
from pokemon_coffee_final import CoffeeDataset as Pokemon
from torch.utils.data import DataLoader
from K_SHADE import K_SHADE

class FinalEnsembleOptimizer:
    """最终版集成优化器"""
    
    def __init__(self):
        self.result_dir = BASE_DIR / "result"
        self.summary_file = self.result_dir / "all_experiments_summary.csv"
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.factory = ModelFactory()
        self.prob_cache = {}
        self.checkpoints = {}
        self.experiment_table = self._load_experiment_table()
        
        # 数据集路径
        data_dir = Path(os.environ.get("PUERTEA_DATA_DIR", BASE_DIR))
        self.data_root = str(data_dir / "data")
        self.csv_file = str(data_dir / "images.csv")
        if not Path(self.data_root).is_dir() or not Path(self.csv_file).is_file():
            raise FileNotFoundError(
                f"请在 {data_dir} 放置 data/ 和 images.csv，或设置 PUERTEA_DATA_DIR"
            )
        
        # 集成模型名称
        self.ensemble_name = "kshade_ensemble"

    def _load_experiment_table(self):
        """读取训练汇总并建立“模型 + 运行编号”到权重的映射。"""
        if not self.summary_file.is_file():
            raise FileNotFoundError(f"训练汇总文件不存在: {self.summary_file}")

        table = pd.read_csv(self.summary_file)
        required = {
            "model_name", "trial_run", "seed", "best_epoch",
            "best_val_acc", "test_acc", "total_time", "checkpoint",
        }
        missing = sorted(required.difference(table.columns))
        if missing:
            raise ValueError(f"训练汇总缺少字段: {missing}")
        if table.empty:
            raise ValueError(f"训练汇总没有记录: {self.summary_file}")

        duplicate = table.duplicated(["model_name", "trial_run"], keep=False)
        if duplicate.any():
            rows = table.loc[duplicate, ["model_name", "trial_run"]].to_dict("records")
            raise ValueError(f"训练汇总存在重复的模型/运行记录: {rows}")

        allowed_models = {
            "resnet18", "swin_t", "convnext_base", "vgg16",
            "densenet169", "efficientnet_b0", "inception_v3",
            "mobilenet_v3_small",
        }
        unknown = sorted(set(table["model_name"]) - allowed_models)
        if unknown:
            raise ValueError(f"训练汇总包含未知模型: {unknown}")

        for row in table.itertuples(index=False):
            run_id = int(row.trial_run)
            checkpoint_name = Path(str(row.checkpoint)).name
            checkpoint_path = self.result_dir / checkpoint_name
            if not checkpoint_path.is_file():
                raise FileNotFoundError(
                    f"权重文件不存在: model={row.model_name}, run={run_id}, "
                    f"checkpoint={checkpoint_path}"
                )
            self.checkpoints[(row.model_name, run_id)] = checkpoint_path

        return table
        
    def get_base_models(self):
        """获取基础模型列表"""
        expected = [
            "resnet18", "swin_t", "convnext_base", "vgg16",
            "densenet169", "efficientnet_b0", "inception_v3",
            "mobilenet_v3_small",
        ]
        available = set(self.experiment_table["model_name"])
        missing = [name for name in expected if name not in available]
        if missing:
            raise ValueError(f"训练汇总缺少基础模型: {missing}")
        return expected

    def get_run_ids(self, models):
        """返回八种模型都具有权重的运行编号。"""
        run_sets = [
            set(self.experiment_table.loc[
                self.experiment_table["model_name"] == name, "trial_run"
            ].astype(int))
            for name in models
        ]
        common_runs = sorted(set.intersection(*run_sets))
        if not common_runs:
            raise ValueError("八种基础模型没有共同的运行编号，无法进行集成")
        return common_runs
    
    def load_predictions(self, model_name, run_id, data_type='val'):
        """加载模型预测概率"""
        key = f"{model_name}_{run_id}_{data_type}"
        if key in self.prob_cache:
            return self.prob_cache[key]
        
        # 模型路径来自训练汇总的 checkpoint 字段
        model_path = self.checkpoints.get((model_name, run_id))
        if model_path is None:
            raise FileNotFoundError(f"找不到模型 {model_name} 的 run_{run_id:03d} 权重记录")
        model = self.factory.create_model(model_name, num_classes=7, pretrained=False)
        try:
            state = torch.load(model_path, map_location=self.device, weights_only=True)
        except TypeError:
            state = torch.load(model_path, map_location=self.device)
        if isinstance(state, dict) and "model_state_dict" in state:
            state = state["model_state_dict"]
        try:
            model.load_state_dict(state)
        except Exception as exc:
            raise RuntimeError(f"权重加载失败: {model_path}: {exc}") from exc
        model = model.to(self.device)
        model.eval()
        
        
        if data_type not in {"train", "val", "test"}:
            raise ValueError(f"未知数据类型: {data_type}")
        input_size = self.factory.get_model_input_size(model_name)
        dataset = Pokemon(self.data_root, self.csv_file, input_size, data_type)
        loader = DataLoader(dataset, batch_size=64, shuffle=False)
        
        # 预测
        probs_list, labels_list = [], []
        with torch.no_grad():
            for x, y in loader:
                x, y = x.to(self.device), y.to(self.device)
                logits = model(x)
                if model_name == 'inception_v3' and hasattr(logits, 'logits'):
                    logits = logits.logits
                probs = torch.softmax(logits, dim=1)
                probs_list.append(probs.cpu().numpy())
                labels_list.append(y.cpu().numpy())
        
        probs = np.vstack(probs_list)
        labels = np.concatenate(labels_list)
        self.prob_cache[key] = (probs, labels)
        return probs, labels
    
    def ensemble_predict(self, encoding, models, run_id, data_type='val'):
        """集成预测"""
        n = len(models)
        sel = encoding[:n]
        w = encoding[n:]
        bin_sel = (sel > 0.5).astype(float)
        
        weighted = bin_sel * w
        total = np.sum(weighted)
        norm_w = weighted / total if total > 0 else np.zeros(n)
        
        ensemble_probs = None
        labels = None
        
        for i, name in enumerate(models):
            if norm_w[i] > 0:
                probs, lbls = self.load_predictions(name, run_id, data_type)
                if labels is None:
                    labels = lbls
                if ensemble_probs is None:
                    ensemble_probs = norm_w[i] * probs
                else:
                    ensemble_probs += norm_w[i] * probs
        
        if ensemble_probs is None:
            probs, lbls = self.load_predictions(models[0], run_id, data_type)
            ensemble_probs = np.zeros_like(probs)
            labels = lbls
        
        return ensemble_probs, labels, norm_w
    
    def objective_function(self, encoding, models, run_id):
        """目标函数"""
        probs, labels, _ = self.ensemble_predict(encoding, models, run_id, 'val')
        preds = np.argmax(probs, axis=1)
        acc = np.mean(preds == labels)
        return -acc
    
    def create_experiment_dir(self, run_id):
        """创建实验目录"""
        exp_dir = self.result_dir / self.ensemble_name / f"run_{run_id:03d}"
        exp_dir.mkdir(parents=True, exist_ok=True)
        return exp_dir
    
    def save_standard_results(self, run_id, best_encoding, models, val_acc, test_acc, 
                            train_preds, train_labels, val_preds, val_labels, 
                            test_preds, test_labels, convergence_curve, total_time):
        """保存标准格式结果"""
        exp_dir = self.create_experiment_dir(run_id)
        start_time = time.time() - total_time
        
        # 1. 保存预测结果CSV
        # 训练集
        train_df = pd.DataFrame({
            'true_label': train_labels,
            'pred_label': train_preds,
            'is_correct': (train_labels == train_preds).astype(int)
        })
        train_df.to_csv(exp_dir / "train_predictions.csv", index=False)
        
        # 验证集
        val_df = pd.DataFrame({
            'true_label': val_labels,
            'pred_label': val_preds,
            'is_correct': (val_labels == val_preds).astype(int)
        })
        val_df.to_csv(exp_dir / "val_predictions.csv", index=False)
        
        # 测试集
        test_df = pd.DataFrame({
            'true_label': test_labels,
            'pred_label': test_preds,
            'is_correct': (test_labels == test_preds).astype(int)
        })
        test_df.to_csv(exp_dir / "test_predictions.csv", index=False)
        
        # 2. 解析选择的模型和权重
        n = len(models)
        sel = best_encoding[:n]
        w = best_encoding[n:]
        bin_sel = (sel > 0.5).astype(float)
        weighted = bin_sel * w
        total = np.sum(weighted)
        norm_w = weighted / total if total > 0 else np.zeros(n)
        
        selected_models = []
        selected_weights = []
        for i, name in enumerate(models):
            if norm_w[i] > 0:
                selected_models.append(name)
                selected_weights.append(float(norm_w[i]))
        
        # 3. 保存实验摘要
        summary = {
            'model_name': [self.ensemble_name],
            'trial_run': [run_id],
            'best_val_accuracy': [val_acc],
            'test_accuracy': [test_acc],
            'total_training_time': [total_time],
            'start_time': [datetime.fromtimestamp(start_time).strftime("%Y-%m-%d %H:%M:%S")],
            'end_time': [datetime.now().strftime("%Y-%m-%d %H:%M:%S")],
            'save_dir': [str(exp_dir)],
            'selected_models': [', '.join(selected_models)],
            'weights': [', '.join([f"{w:.4f}" for w in selected_weights])],
            'num_selected_models': [len(selected_models)]
        }
        pd.DataFrame(summary).to_csv(exp_dir / "experiment_summary.csv", index=False)
        
        # 4. 保存集成配置
        config = {
            'ensemble_name': self.ensemble_name,
            'run_id': run_id,
            'base_models': models,
            'encoding': best_encoding.tolist(),
            'selected_models': selected_models,
            'weights': selected_weights,
            'val_accuracy': float(val_acc),
            'test_accuracy': float(test_acc),
            'optimization_time': total_time
        }
        with open(exp_dir / "ensemble_config.json", 'w') as f:
            json.dump(config, f, indent=2)
        
        # 5. 保存收敛曲线
        curve_df = pd.DataFrame({
            'iteration': range(len(convergence_curve)),
            'best_val_acc': [-x for x in convergence_curve]
        })
        curve_df.to_csv(exp_dir / "convergence_curve.csv", index=False)
        
        print(f"标准格式结果已保存到: {exp_dir}")
        return exp_dir
    
    def optimize_and_save(self, models, run_id, pop_size=30, max_iter=50):
        """优化并保存结果"""
        n = len(models)
        dim = 2 * n
        
        def fobj(x):
            return self.objective_function(x, models, run_id)
        
        print(f"\n优化 run_{run_id:03d} (模型: {n}, 维度: {dim})")
        start_time = time.time()
        
        # K-SHADE优化
        try:
            fmin, best_enc, curve = K_SHADE(
                n=pop_size,
                N_iter=max_iter,
                Lb=[0] * dim,
                Ub=[1] * dim,
                dim=dim,
                fobj=fobj,
            )
        except Exception as exc:
            raise RuntimeError(f"K-SHADE 优化失败: {exc}") from exc

        best_enc = np.asarray(best_enc, dtype=float).reshape(-1)
        curve = np.asarray(curve, dtype=float).reshape(-1)
        try:
            fmin = float(fmin)
        except (TypeError, ValueError) as exc:
            raise RuntimeError(f"K-SHADE 返回了无效的最优目标值: {fmin!r}") from exc

        if best_enc.size != dim:
            raise RuntimeError(
                f"K-SHADE 返回的编码长度错误: expected={dim}, actual={best_enc.size}"
            )
        if not np.all(np.isfinite(best_enc)):
            raise RuntimeError("K-SHADE 返回的最优编码包含 NaN 或无穷值")
        if not np.isfinite(fmin):
            raise RuntimeError(f"K-SHADE 返回的最优目标值无效: {fmin}")
        if curve.size == 0 or not np.all(np.isfinite(curve)):
            raise RuntimeError("K-SHADE 返回的收敛曲线为空或包含无效数值")

        optimized_val_acc = -fmin
        
        # 获取各种预测
        train_probs, train_labels, _ = self.ensemble_predict(best_enc, models, run_id, 'train')
        val_probs, val_labels, _ = self.ensemble_predict(best_enc, models, run_id, 'val')
        test_probs, test_labels, _ = self.ensemble_predict(best_enc, models, run_id, 'test')
        
        train_preds = np.argmax(train_probs, axis=1)
        val_preds = np.argmax(val_probs, axis=1)
        test_preds = np.argmax(test_probs, axis=1)
        val_acc = float(np.mean(val_preds == val_labels))
        test_acc = float(np.mean(test_preds == test_labels))
        print(
            f"K-SHADE目标验证准确率: {optimized_val_acc:.4f}, "
            f"重新计算验证准确率: {val_acc:.4f}"
        )
        
        total_time = time.time() - start_time
        
        # 保存标准格式结果
        exp_dir = self.save_standard_results(
            run_id, best_enc, models, val_acc, test_acc,
            train_preds, train_labels, val_preds, val_labels,
            test_preds, test_labels, curve, total_time
        )
        
        result = {
            'run_id': run_id,
            'val_acc': float(val_acc),
            'test_acc': float(test_acc),
            'total_time': float(total_time),
            'save_dir': str(exp_dir)
        }
        
        print(f"完成! Val: {val_acc:.4f}, Test: {test_acc:.4f}, 时间: {total_time:.1f}s")
        return result
    
    def run_all(self):
        """运行所有实验"""
        models = self.get_base_models()
        print(f"基础模型 ({len(models)}个): {models}")
        run_ids = self.get_run_ids(models)
        print(f"共同运行编号 ({len(run_ids)}个): {run_ids}")
        
        all_results = []
        for run_id in run_ids:
            try:
                print(f"\n{'='*60}")
                print(f"实验 run_{run_id:03d}")
                print(f"{'='*60}")
                
                result = self.optimize_and_save(models, run_id)
                all_results.append(result)
                
            except Exception as e:
                print(f"run_{run_id:03d} 错误: {e}")
                continue
        
        self.save_final_summary(all_results)
        return all_results
    
    def save_final_summary(self, results):
        """保存最终汇总"""
        if not results:
            return
        
        # 汇总表格
        summary_data = []
        for r in results:
            # 读取实验摘要获取详细信息
            exp_dir = Path(r['save_dir'])
            summary_file = exp_dir / "experiment_summary.csv"
            if summary_file.exists():
                df = pd.read_csv(summary_file)
                if not df.empty:
                    summary_data.append({
                        'run_id': r['run_id'],
                        'val_accuracy': df.iloc[0]['best_val_accuracy'],
                        'test_accuracy': df.iloc[0]['test_accuracy'],
                        'num_selected_models': df.iloc[0]['num_selected_models'],
                        'selected_models': df.iloc[0]['selected_models'],
                        'weights': df.iloc[0]['weights'],
                        'total_time': r['total_time'],
                        'save_dir': r['save_dir']
                    })
        
        if summary_data:
            df = pd.DataFrame(summary_data)
            save_path = self.result_dir / self.ensemble_name / "all_experiments_summary.csv"
            save_path.parent.mkdir(parents=True, exist_ok=True)
            df.to_csv(save_path, index=False)
            
            # 统计信息
            avg_val = np.mean([r['val_accuracy'] for r in summary_data])
            avg_test = np.mean([r['test_accuracy'] for r in summary_data])
            avg_time = np.mean([r['total_time'] for r in summary_data])
            
            print(f"\n{'='*60}")
            print("最终汇总统计")
            print(f"{'='*60}")
            print(f"平均验证准确率: {avg_val:.4f}")
            print(f"平均测试准确率: {avg_test:.4f}")
            print(f"平均运行时间: {avg_time:.1f}s")
            print(f"完成实验数: {len(results)}")
            print(f"汇总文件: {save_path}")


def main():
    """主函数"""
    print("=" * 60)
    print("K-SHADE集成优化器 (标准格式)")
    print("=" * 60)
    
    optimizer = FinalEnsembleOptimizer()
    results = optimizer.run_all()
    
    print(f"\n所有 {len(results)} 个实验完成!")
    print(f"结果保存在: {BASE_DIR / 'result' / 'kshade_ensemble'}")
    return results


if __name__ == "__main__":
    main()
